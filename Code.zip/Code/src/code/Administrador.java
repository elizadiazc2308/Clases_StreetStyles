/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package code;

/**
 *
 * @author sr860
 */
public class Administrador {
     public void gestionarUsuario() { }
    public void gestionarContenido() { }
    public void generarReportes() { } 
}
