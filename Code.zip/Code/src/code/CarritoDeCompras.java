/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package code;
import java.util.List;
/**
 *
 * @author sr860
 */
public class CarritoDeCompras {
     private String carritoId;
    private Cliente cliente;
    private List<Producto> items;

    public void agregarItem() { }
    public void eliminarItem() { }
    public void calcularTotal() { }
}
