/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package code;
import java.util.List;
/**
 *
 * @author sr860
 */
public class Cliente extends Usuario {
    private CarritoDeCompras carrito;
    private List<Pedido> historialPedidos;
    public void agregarAlCarrito() { }
    public void realizarPedido() { }
    public void personalizarProducto() { }
}
