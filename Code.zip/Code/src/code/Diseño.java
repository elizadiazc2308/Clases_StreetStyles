/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package code;
import java.util.List;
/**
 *
 * @author sr860
 */
public class Diseño {
    private String diseñoId;
    private String titulo;
    private Diseñador diseñador;
    private String archivoDiseño;
    private List<String> etiquetas;

    public void editarDiseño() { }
    public void eliminarDiseño() { }
}
